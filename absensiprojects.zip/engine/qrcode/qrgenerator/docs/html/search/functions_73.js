var searchData=
[
  ['serial',['serial',['../class_q_rspec.html#a0efcd2f1dd61e54611feeab74d4972e3',1,'QRspec']]],
  ['set',['set',['../class_q_rspec.html#aa927b92e77df1f2034913b9e1963986c',1,'QRspec']]],
  ['setframeat',['setFrameAt',['../class_q_rframe_filler.html#a8717aa2aa6dbcd7c90133792849728a2',1,'QRframeFiller']]],
  ['size',['size',['../class_q_rbitstream.html#a3bed2132f1aec1d11473c284b7321cb3',1,'QRbitstream']]],
  ['svg',['svg',['../class_q_rcode.html#a952a9d42bdd7cfa8249757d7a87d9e63',1,'QRcode']]]
];
