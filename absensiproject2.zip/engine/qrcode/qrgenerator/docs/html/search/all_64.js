var searchData=
[
  ['debug',['debug',['../class_q_rspec.html#a2e597199e2a6a4e04ba44a1ec1a8f7be',1,'QRspec']]]
];
