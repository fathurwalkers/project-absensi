var searchData=
[
  ['unserial',['unserial',['../class_q_rspec.html#abfc4c308b6fd7720a200c139997c336d',1,'QRspec']]]
];
