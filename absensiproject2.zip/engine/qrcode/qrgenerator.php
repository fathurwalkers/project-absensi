<?php
require_once 'qrgenerator/lib/full/qrlib.php';
require_once '../functions.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>



    <?php


    $result = mysqli_fetch_assoc($select);
    var_dump($result);
    echo "<br>";
    echo "<br>";
    $namalengkap = $result["namalengkap"];
    echo $namalengkap;
    echo "<br>";
    die();

    if (isset($_POST["generate"])) {

        //$text = $_POST[];

        $path = '../../assets/img/qrimage/';
        $file = $path . uniqid() . ".png";

        $qrtext = "|fathurwalkers|b9731f994fc1007c21778e52239a1405cd9cea3|";

        $generated = QRcode::png($qrtext, $file, 'L', 10, 2);

        echo "<center><img src='" . $file . "'></center>";
    }

    ?>


</body>

</html>